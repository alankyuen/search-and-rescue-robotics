from cluster_test import*
from dbscan_test import*
from constants_test import*
from field_test import*
from dronekit import LocationGlobal

################################################################################################
"""
GOALS:
Saturday [5/13] Testable SARA
Monday Night[5/8] SARA can move to a waypoint, and non-router methods
Wednesday Night[5/10] SARA has navigation capabilities (spiral and manually-placed)
Friday Night [5/12] SARA fully autonomous, navigating a path and recording lidar data.


TASK LIST:

-Goto()
    1) does anybody know any possible ways? mission planner?
    2) what does the current simple_goto() do now? is there a way to view the innards of PH?
    3) before we commit to any decision to an attempt to fix it, how long will it take? anything possibly faster?

-WP Path:
    1) does the waypoint generator work?
    2) just in case the robot's compass is not very accurate and the waypoint generator will produce a path that is dangerous for SARA
        can you have a backup system for manual waypoint inputs

-mobile hotspot to replace router:
    1) is it possible?

-system testing
    1)do all of the functions that we've written work?
    2)can we test a series of points to see if it flows correctly?
    3)can we get good testing data quickly?
"""
################################################################################################


"""
top left: 33.649754, -117.849540
bottom left: 33.648467, -117.850491
bottom right: 33.647679, -117.849021 
top right: 33.649085, -117.848014
gps_tl = LocationGlobal(33.649754, -117.849540, 0)
gps_bl = LocationGlobal(33.648467, -117.850491, 0)
gps_br = LocationGlobal(33.647679, -117.849021, 0)
gps_tr = LocationGlobal(33.649085, -117.848014, 0)


#point(ts, gps_reading, [lidar heading from robot, dist, q], robot heading from field)
p1 = point(1500,gps_tl,[30, 60000, 25], 90)
p2 = point(3000,gps_tl,[30,5000,25],90)
field_bearing = get_bearing(gps_tl, gps_bl)
p1.calculateAbsPos(gps_tl, field_bearing)
p1.printPt(calculated = True)
"""

gps_tl = LocationGlobal(33.649897, -117.848503, 0)
gps_bl = LocationGlobal(33.649815, -117.848561, 0)
gps_br = LocationGlobal(33.649703, -117.848345, 0)
gps_tr = LocationGlobal(33.649785, -117.848283, 0)

"""
class "field":
    __init__:
        const vars: field_dimensions_ft/m, effective_sensor_range_ft/m, grid_dimensions(ft/m)
        data struct: cells[r][c]
        calculated vars: field_bearing, gps_waypoints, ft_waypoints
        dbscan vars: buckets_gps

    waypointGen [_]
        variables: field_width, S_R
        methods used: calcGPS_from_map

    addPoint [_]
        adds point to appropriate cell
        returns cell index that it has the point inserted into

    getPaddedCell [_]
        returns points of cell and neighboring points for DBSCAN

"""


gps_tl = LocationGlobal(33.649897, -117.848503, 0)
gps_bl = LocationGlobal(33.649815, -117.848561, 0)
gps_br = LocationGlobal(33.649703, -117.848345, 0)
gps_tr = LocationGlobal(33.649785, -117.848283, 0)

gps_tl2 = LocationGlobal(33.649754, -117.849540,0)
gps_bl2 = LocationGlobal(33.648467, -117.850491,0)
gps_br2 = LocationGlobal(33.647679, -117.849021,0)
gps_tr2 = LocationGlobal(33.649085, -117.848014,0)

f1 = field()
for wps in f1.waypointGen(gps_tr2, get_bearing(gps_tr2, gps_br2)):
    printGPS(wps)
print(f1.ft_waypoints)
